# Mastermind (React + Vite)

A simple Mastermind game. The secret is a sequence of 4 colors from a palette of 6. Pick colors for each slot and submit your guess. The history lists your previous attempts with feedback:

- Exact: right color in the right position
- Partial: right color in the wrong position

Right-click a slot to clear it. Use “New Game” to generate a new secret.

## Run locally

1. Install dependencies
2. Start the dev server

```pwsh
npm install
npm run dev
```

Then open the printed local URL in your browser.

## Build

```pwsh
npm run build
npm run preview
```

## Tech

- React 18
- Vite 5
- TypeScript 5

## Notes

- The solution can include repeated colors.
- For accessibility: buttons have titles; keyboard users can select slots then choose colors.
